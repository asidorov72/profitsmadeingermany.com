<?php
/**
 * EDigital functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Mystery Themes
 * @subpackage EDigital
 * @since 1.0.0
 */

if ( ! function_exists( 'edigital_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function edigital_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on EDigital, use a find and replace
	 * to change 'edigital' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'edigital', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 */
	add_theme_support( 'custom-logo', array(
			'height' => 175,
			'width'  => 400,
			'flex-width' => true
		) );
    
    add_image_size( 'edigital-home-blog', 380, 240, true );
    add_image_size( 'edigital-slider-img', 1920, 1000, true );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'edigital_primary' => esc_html__( 'Primary Menu', 'edigital' ),
		'edigital_footer' => esc_html__( 'Footer Menu', 'edigital' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'edigital_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif;
add_action( 'after_setup_theme', 'edigital_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function edigital_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'edigital_content_width', 640 );
}
add_action( 'after_setup_theme', 'edigital_content_width', 0 );

/**
 * Set the global variable about theme version
 *
 * @global int $edigital_version
 * @since 1.0.7
 */
function edigital_theme_version() {
	$edigital_theme_info = wp_get_theme();
	$GLOBALS['edigital_version'] = $edigital_theme_info->get( 'Version' );
}
add_action( 'after_setup_theme', 'edigital_theme_version', 0 );

/**
 * Implement the Custom functions
 */
require get_template_directory() . '/inc/edigital-functions.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Load widget area
 */
require get_template_directory() . '/inc/widgets/edigital-widget-functions.php';

/**
 * Custom classes for customizer options
 */
require get_template_directory() . '/inc/customizer/customizer-classes.php';

/**
 * customizer field sanitize
 */
require get_template_directory() . '/inc/customizer/customizer-sanitize.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';
require get_template_directory() . '/inc/customizer/general-panel.php'; // General Settings Panel
require get_template_directory() . '/inc/customizer/frontpage-panel.php'; // FrontPage Settings Panel
require get_template_directory() . '/inc/customizer/innerpages-panel.php'; // InnerPages Settings Panel
require get_template_directory() . '/inc/customizer/additional-panel.php'; // Additional Settings Panel
require get_template_directory() . '/inc/customizer/footer-panel.php'; // Footer Settings Panel

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load metabox
 */
require get_template_directory() . '/inc/metaboxes/edigital-post-metabox.php';

/**
 * Load theme about page
 */
require get_template_directory(). '/inc/about-theme/edigital-about.php';




/* EDD Ordering by menu_order field */
function my_child_theme_edd_download_supports( $supports ) {
	// add page-attributes
	$add_support = array( 'page-attributes' );
	// merge it back with the original array
	return array_merge( $add_support, $supports );
}
add_filter( 'edd_download_supports', 'my_child_theme_edd_download_supports' );

function my_child_theme_edd_downloads_query( $query, $atts ) {
	// modify order and orderby to suit simple page ordering plugin
	$query['orderby']	= 'menu_order';
	$query['order'] 	= 'ASC';

	return $query;
}
add_filter( 'edd_downloads_query', 'my_child_theme_edd_downloads_query', 10, 2 );
