#  Easy Digital Downloads i18n #

  To help translate, review, or improve a translation, join our Translations Community at
  https://translate.wordpress.org/projects/wp-plugins/easy-digital-downloads

  More info at https://make.wordpress.org/polyglots/

