=== Plugin Name ===

Tags: recent downloads, widget, easy digital downloads

Adds a widget that can display recent downloads for Easy Digital Downloads.


== Description ==


This is an extension for Easy Digital Downloads that allows you to display a list of the most recent downloads. It is simple and light widget.



== Installation ==

1. Download the plugin.

2. Upload it to the plugins folder of your blog.

3. Goto the Plugins section of the WordPress admin and activate the plugin.

4. Goto the Widget tab of the Presentation section and configure the widget.