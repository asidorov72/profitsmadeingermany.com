<?php
/**
 * Do not put custom translations here. They will be deleted on 'Easy Digital Downloads Search Widget' updates!
 *
 * Keep custom 'Easy Digital Downloads Search Widget' translations in '/wp-content/languages/edd-search-widget/'
 */
