===Hide Admin Bar From Front End ===
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=amu02.aftab@gmail.com&item_name=Hide+Admin+Bar+From+Front+End
Tags: Hide Admin Bar, Hide Admin Bar From Front End
Contributors: amu02aftab
Author: amu02aftab
Tested up to: 4.7
License: GPLv2
Requires at least: 3.5.0
Stable tag: 1.0

== Description ==
This plugin provides  feature to hide/show admin bar from front end.
 
<strong>Feature</strong>

* Setting to Hide/Show Admin Bar in admin 


== Screenshots ==

1. Back End Hide/Show Admin Bar setting 


== Frequently Asked Questions ==
1. No technical skills needed.

== Changelog ==
This is first version no known errors found

== Upgrade Notice == 
This is first version no known notices yet

== Installation ==
1. Upload the folder "hide-admin-bar-from-front-end" to "/wp-content/plugins/"
2. Activate the plugin through the "Plugins" menu in WordPress
3. Manage setting to 'Hide/Show Admin Bar' by going WP-admin -> Settings ->Hide/Show Admin Bar
4. Enjoy! as there is setting to show/hide in admin. 



